<?php
require __DIR__ . "/../config/cors.php";
require __DIR__ . "/../config/session.php";
$_SESSION = [];
session_destroy();

echo json_encode(["success" => true]);