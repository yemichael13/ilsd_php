<?php
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);

$host = trim((string) (getenv('DB_HOST') ?: 'localhost'));
$port = trim((string) (getenv('DB_PORT') ?: '3306'));
$db = trim((string) (getenv('DB_NAME') ?: 'ilsd_db'));
$user = (string) (getenv('DB_USER') ?: 'root');
$pass = (string) (getenv('DB_PASSWORD') ?: 'Ineedyouthere@1@3');

try {
    $pdo = new PDO(
        "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'error' => 'Database connection failed',
        'message' => 'Configure DB_HOST, DB_PORT, DB_NAME, DB_USER, and DB_PASSWORD on the production server.',
    ]);
    exit;
}
